document.addEventListener('DOMContentLoaded', function() {
    // Função para adicionar itens ao pedido
    function adicionarAoPedido() {
        let pedidos = [];

        // Captura os sabores de cuscuz selecionados
        document.querySelectorAll('input[name="saborCuscuz"]:checked').forEach(cuscuz => {
            let nome = cuscuz.value;
            let quantidade = cuscuz.closest('label').querySelector('input[type="number"]').value || 1;
            // Limita a quantidade a 10 e avisa o usuário
            if (quantidade > 10) {
                alert('O limite de quantidade para cada item é 10.');
                quantidade = 10; // Ajusta para 10
            }
            let preco = nome === 'Carne de Sol' ? 13 : 10; // Preço simplificado
            pedidos.push({ nome, preco, quantidade });
        });

        // Captura as bebidas selecionadas
        document.querySelectorAll('input[name="bebida"]:checked').forEach(bebida => {
            let nome = bebida.value;
            let quantidade = bebida.closest('label').querySelector('input[type="number"]').value || 1;
            if (quantidade > 10) {
                alert('O limite de quantidade para cada item é 10.');
                quantidade = 10; // Ajusta para 10
            }
            let preco = 5; // Preço fixo para todas as bebidas
            pedidos.push({ nome, preco, quantidade });
        });

        // Armazenar os pedidos no localStorage
        localStorage.setItem('pedidos', JSON.stringify(pedidos));

        // Captura as informações de nome, endereço e telefone
        const nome = document.getElementById('nome').value;
        const endereco = document.getElementById('endereco').value;
        const telefone = document.getElementById('telefone').value;

        // Verifica se os campos obrigatórios estão preenchidos
        if (!nome || !endereco || !telefone) {
            alert('Por favor, preencha todos os campos obrigatórios (nome, endereço e telefone).');
            return; // Não permite o redirecionamento
        }

        // Armazenar as informações de contato no localStorage
        localStorage.setItem('pedidoInfo', JSON.stringify({ nome, endereco, telefone }));

        // Verifica se pelo menos um pedido foi selecionado
        if (pedidos.length === 0) {
            alert('Por favor, selecione pelo menos um pedido.');
            return; // Não permite o redirecionamento
        }

        // Se tudo estiver certo, redireciona para a página de pagamento
        window.location.href = 'pagamento.html';
    }

    // Adicionar evento ao botão de visualizar pedido
    const botaoVisualizarPedido = document.getElementById('visualizarPedido');
    if (botaoVisualizarPedido) {
        botaoVisualizarPedido.addEventListener('click', function(event) {
            event.preventDefault(); // Evita comportamento padrão do botão
            adicionarAoPedido(); // Adiciona os pedidos e informações ao localStorage
        });
    }

    // Função para carregar os pedidos na página de pagamento
    function carregarPedidos() {
        const pedidos = JSON.parse(localStorage.getItem('pedidos')) || [];
        const pedidosContainer = document.getElementById('pedidosContainer');

        if (pedidos.length === 0) {
            pedidosContainer.innerHTML = '<p>Nenhum pedido foi selecionado.</p>';
        } else {
            let html = '<ul>';
            pedidos.forEach(pedido => {
                html += `<li>${pedido.nome} - Quantidade: ${pedido.quantidade} - Preço: R$ ${(pedido.preco * pedido.quantidade).toFixed(2)}</li>`;
            });
            html += '</ul>';
            pedidosContainer.innerHTML = html;
        }

        // Carregar as informações de nome, endereço e telefone
        const pedidoInfo = JSON.parse(localStorage.getItem('pedidoInfo')) || {};
        const nomeContainer = document.getElementById('nomeContainer');
        const enderecoContainer = document.getElementById('enderecoContainer');
        const telefoneContainer = document.getElementById('telefoneContainer');

        if (nomeContainer) {
            nomeContainer.innerHTML = `Nome: ${pedidoInfo.nome || 'Não informado'}`;
        }
        if (enderecoContainer) {
            enderecoContainer.innerHTML = `Endereço: ${pedidoInfo.endereco || 'Não informado'}`;
        }
        if (telefoneContainer) {
            telefoneContainer.innerHTML = `Telefone: ${pedidoInfo.telefone || 'Não informado'}`;
        }
    }

    // Carregar os pedidos e informações quando a página de pagamento for aberta
    if (window.location.pathname.includes('pagamento.html')) {
        carregarPedidos();
    }
});

// Função para confirmar o pedido via WhatsApp
function confirmarPedidoWhatsApp() {
    const pedidos = JSON.parse(localStorage.getItem('pedidos')) || [];
    const pedidoInfo = JSON.parse(localStorage.getItem('pedidoInfo')) || {};

    if (pedidos.length === 0) {
        alert("Nenhum pedido foi selecionado.");
        return;
    }

    let mensagem = `Olá, gostaria de confirmar o seguinte pedido:\n`;
    // Adiciona informações do usuário
    mensagem += `\nNome: ${pedidoInfo.nome}\n`;
    mensagem += `Endereço: ${pedidoInfo.endereco}\n`;
    mensagem += `Telefone: ${pedidoInfo.telefone}\n`;

    // Adiciona os pedidos
    pedidos.forEach(pedido => {
        mensagem += `\n- ${pedido.nome}: Quantidade ${pedido.quantidade}, Preço R$ ${(pedido.preco * pedido.quantidade).toFixed(2)}`;
    });

    const numeroWhatsApp = '559991545687';
    const url = `https://wa.me/${numeroWhatsApp}?text=${encodeURIComponent(mensagem)}`;

    window.open(url, '_blank');
}

// Função para abrir o modal
function openModal() {
    document.getElementById("contactModal").style.display = "block";
}

// Função para fechar o modal
function closeModal() {
    document.getElementById("contactModal").style.display = "none";
}
// Fecha o modal se o usuário clicar fora dele
window.onclick = function(event) {
    var modal = document.getElementById("contactModal");
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// Função de navegação suave entre seções
document.querySelectorAll('.nav-link').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        const targetSection = document.querySelector(targetId);

        if (targetSection) {
            targetSection.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});